import typer

app = typer.Typer()

@app.command()
def hello(nam: str):
    print(f"Hello {nam}")

if __name__ == "__main__":
    app()